* Y=fft(x,n,dim)
	* n 如何取值
		* 比向量长度略大的2的整次幂的
			* nextpow2
	* dim 维度
		* 一般2维
	* Y->双侧->单侧
